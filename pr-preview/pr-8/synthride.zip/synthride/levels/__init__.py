# Copyright (c) 2026 Renaud Guillon
# SPDX-License-Identifier: MIT

"""Bundled level files."""
