# Copyright (c) 2026 Renaud Guillon
# SPDX-License-Identifier: MIT

"""The 3D level editor: brushes painting the track under the mouse."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, replace
from html import escape
from typing import TYPE_CHECKING, ClassVar

from synthride.core.world.slope import Slope
from synthride.core.world.tile import Tile
from synthride.core.world.tile_type import TileType
from synthride.core.world.track import Track
from synthride.core.world.track_parser import TrackParser
from synthride.editor.track_grid import Brush, BrushKind, LevelSettings, Rect, TrackGrid
from synthride.editor.track_picker import TrackPicker
from synthride.web.rendering.palette import Palette

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from synthride.core.world.level import Level
    from synthride.web.browser.js_bridge import JsBridge, JsObject


@dataclass(frozen=True)
class Tool:
    """A brush as the toolbar shows it: its icon, its colour, what it does and the group it sits in."""

    name: str
    glyph: str
    color: int
    label: str
    brush: Brush
    group: str = "tiles"


def _tile(tile_type: TileType, glyph: str, label: str) -> Tool:
    color = Palette.tile_color(tile_type)
    return Tool(tile_type.name.lower(), glyph, color, label, Brush(BrushKind.TILE, tile_type.value))


# The icon of each slope: its filled part is the raised side or corner (the front is up the screen).
SLOPE_GLYPHS: dict[Slope, tuple[str, str]] = {
    Slope.FRONT: ("⬒", "Ramp rising ahead"),
    Slope.BACK: ("⬓", "Ramp falling ahead"),
    Slope.LEFT: ("◧", "Ramp rising to the left"),
    Slope.RIGHT: ("◨", "Ramp rising to the right"),
    Slope.FRONT_LEFT: ("◤", "Corner rising ahead and to the left"),
    Slope.FRONT_RIGHT: ("◥", "Corner rising ahead and to the right"),
    Slope.BACK_LEFT: ("◣", "Corner rising behind and to the left"),
    Slope.BACK_RIGHT: ("◢", "Corner rising behind and to the right"),
}
SLOPE_COLOR = 0xFFB347


def _slope(slope: Slope) -> Tool:
    glyph, label = SLOPE_GLYPHS[slope]
    return Tool(f"ramp_{slope.name.lower()}", glyph, SLOPE_COLOR, label, Brush(BrushKind.SHAPE, slope.value), "slopes")


class EditorScreen:
    """The level editor, over the 3D view of the track being edited.

    The mouse wheel moves the camera along the track. Pressing on the track and releasing paints the rectangle between
    the two cells with the selected brush; the right button erases. New tiles stand at the selected height. The
    toolbar holds the brushes, the heights and the track's settings. Starting a test ride and leaving the editor are
    left to the game loop, as actions it collects with :meth:`consume_actions`.

    Saving posts the level file to the dev server, which writes it into the bundled levels: over the file of the level
    being edited, or as a new file after the last one.
    """

    RIDE: ClassVar[str] = "ride"
    BACK: ClassVar[str] = "back"
    ERASER: ClassVar[Tool] = Tool("erase", "⌫", 0xFF6D6D, "Erase: leave a gap", Brush(BrushKind.ERASE), "edit")
    TOOLS: ClassVar[tuple[Tool, ...]] = (
        _tile(TileType.NORMAL, "■", "Solid ground"),
        _tile(TileType.BOOST, "︿", "Boost: speed burst"),
        _tile(TileType.SLOW, "﹀", "Slow: brakes you"),
        _tile(TileType.ICE, "✳", "Ice: no grip"),
        _tile(TileType.KILL, "▨", "Kill: burns"),
        _tile(TileType.JUMP, "⇡", "Jump pad: launches you"),
        _tile(TileType.REFUEL, "+", "Refuel"),
        _tile(TileType.AIR, "○", "Oxygen refill"),
        _tile(TileType.PUSH_LEFT, "◂", "Pushes left"),
        _tile(TileType.PUSH_RIGHT, "▸", "Pushes right"),
        _tile(TileType.FINISH, "▚", "Finish line"),
        ERASER,
        Tool("raise", "⬆", 0xFFFFFF, "Raise one height", Brush(BrushKind.RAISE), "edit"),
        Tool("lower", "⬇", 0xFFFFFF, "Lower one height", Brush(BrushKind.LOWER), "edit"),
        *(_slope(slope) for slope in Slope),
        Tool("tunnel", "∩", Palette.TUNNEL, "Square tunnel", Brush(BrushKind.SHAPE, "T"), "shapes"),
        Tool("round_tunnel", "◠", Palette.TUNNEL, "Round tunnel", Brush(BrushKind.SHAPE, "A"), "shapes"),
        Tool("flat", "▬", 0xFFFFFF, "Flat and open: no ramp, no tunnel", Brush(BrushKind.SHAPE, ""), "shapes"),
    )
    # (action, label): the buttons acting on the whole track
    ACTIONS: ClassVar[tuple[tuple[str, str], ...]] = (
        ("undo", "↶ Undo"),
        (RIDE, "▶ Test ride"),
        ("save", "Save"),
        ("new", "New"),
        (BACK, "Back"),
    )
    # (field, label, low, high): the track's settings
    SETTINGS: ClassVar[tuple[tuple[str, str, int, int], ...]] = (
        ("gravity", "GRAVITY", 5, 40),
        ("fuel", "FUEL", 10, 999),
        ("oxygen", "OXYGEN", 10, 999),
    )
    KEYS: ClassVar[str] = (
        "WHEEL / ↑ ↓ move &nbsp;·&nbsp; DRAG paint &nbsp;·&nbsp; RIGHT DRAG erase &nbsp;·&nbsp; 1-8 height"
        " &nbsp;·&nbsp; Q E brush &nbsp;·&nbsp; Z undo &nbsp;·&nbsp; T test ride &nbsp;·&nbsp; ESC back"
    )
    SCROLL_KEYS: ClassVar[dict[str, float]] = {"ArrowUp": 4.0, "ArrowDown": -4.0}
    # The shortcuts named after a letter, by the letter the key types on the player's layout.
    LETTER_ACTIONS: ClassVar[dict[str, str]] = {"q": "previous_tool", "e": "next_tool", "z": "undo", "t": RIDE}
    DIGITS: ClassVar[tuple[str, ...]] = ("Digit", "Numpad")
    ROWS_PER_WHEEL: ClassVar[float] = 0.04  # rows per pixel of wheel travel
    SCROLL_RATE: ClassVar[float] = 12.0
    VIEW_ROWS: ClassVar[int] = 6  # how far ahead of the camera's point the ground height is judged
    MARGIN_ROWS: ClassVar[int] = 40  # how far past the end of the track the camera may go
    CURSOR_LIFT: ClassVar[float] = 0.04
    GUIDE_BEHIND: ClassVar[int] = 6  # rows of the guide grid behind the camera's point
    GUIDE_ROWS: ClassVar[int] = 80
    GUIDE_COLOR: ClassVar[int] = 0x00F0FF
    GUIDE_LIFT: ClassVar[float] = 0.01
    LEVELS_URL: ClassVar[str] = "levels/"
    FILE_NAME: ClassVar[re.Pattern[str]] = re.compile(r"level_(\d+)\.json")

    def __init__(
        self,
        bridge: JsBridge,
        surface: JsObject,
        camera: JsObject,
        files: Sequence[str] = (),
        on_saved: Callable[[int, Level], object] | None = None,
    ) -> None:
        """Render the toolbar into the ``editor`` element and paint with the mouse on ``surface``, seen by ``camera``.

        ``files`` names the level files, in the order of the levels. Once the server has saved a level,
        ``on_saved`` gets its index among them and the level.
        """
        self._bridge = bridge
        self._document = bridge.document
        self._container = self._document.getElementById("editor")
        self._surface = surface
        self._camera = camera
        self.files = list(files)
        self._on_saved = on_saved
        self.grid = TrackGrid.starter()
        self.settings = LevelSettings()
        self.index: int | None = None  # the level being edited, None for a new one
        self._saving: tuple[int, str, TrackGrid, Level] | None = None
        self.tool = self.TOOLS[0]
        self.height = 1
        self.row = 0.0  # where the camera looks, in rows from the start
        self._target_row = 0.0
        self.message = ""
        self.hover: tuple[int, int] | None = None
        self._anchor: tuple[int, int] | None = None
        self._dragging: Tool | None = None
        self._pointer: tuple[float, float] | None = None
        self._level: Level | None = None
        self._actions: list[str] = []
        self._mounted = False
        self._active = False
        self._shown: dict[str, str] = {}
        self.cursor = self._make_cursor()
        self.guide = self._make_guide()
        self._saved_proxy = bridge.proxy(self.on_save_response)
        self._failed_proxy = bridge.proxy(self.on_save_failed)
        self._refused_proxy = bridge.proxy(self.on_save_refused)
        container = self._container
        container.addEventListener("click", bridge.proxy(self.on_click))
        container.addEventListener("change", bridge.proxy(self.on_change))
        surface.addEventListener("pointerdown", bridge.proxy(self.on_pointer_down))
        surface.addEventListener("pointermove", bridge.proxy(self.on_pointer_move))
        surface.addEventListener("pointerup", bridge.proxy(self.on_pointer_up))
        surface.addEventListener("pointerleave", bridge.proxy(self.on_pointer_leave))
        surface.addEventListener("contextmenu", bridge.proxy(self.on_context_menu))
        surface.addEventListener("wheel", bridge.proxy(self.on_wheel), bridge.obj(passive=False))

    # The track being edited

    @property
    def level(self) -> Level:
        """The level the grid makes, built again after each change."""
        if self._level is None:
            self._level = self.settings.level(self.grid)
        return self._level

    def open(self, settings: LevelSettings, grid: TrackGrid, index: int | None = None) -> None:
        """Edit ``grid`` with ``settings``: the level at ``index``, or a new one when None."""
        self.settings, self.grid, self.index = settings, grid, index
        self.row = self._target_row = 0.0
        self.message = ""
        self._changed()
        self._sync_fields()
        self.refresh()

    def open_level(self, level: Level, index: int | None = None) -> None:
        """Edit ``level``, the level at ``index``, or a copy saved as a new level when None."""
        self.open(LevelSettings.of(level), TrackGrid.from_track(level.track), index)

    @property
    def file(self) -> str:
        """The file the track is saved to: its level's, or a new one after the last."""
        if self.index is not None and self.index < len(self.files):
            return self.files[self.index]
        numbers = [int(match[1]) for name in self.files if (match := self.FILE_NAME.fullmatch(name))]
        return f"level_{max(numbers, default=0) + 1:02d}.json"

    def consume_actions(self) -> list[str]:
        """Return the actions for the game loop since the last call: :attr:`RIDE` or :attr:`BACK`."""
        actions, self._actions = self._actions, []
        return actions

    @property
    def focus(self) -> tuple[float, float, float]:
        """The point the camera looks at, ``(x, z, ground)`` in world coordinates."""
        first = max(0, math.floor(self.row))
        levels = [
            int(cell[1])
            for row in range(first, first + self.VIEW_ROWS)
            for column in range(Track.COLUMNS)
            if (cell := self.grid.cell(column, row)) is not None
        ]
        ground = max(levels, default=self.height) * Tile.HEIGHT_UNIT
        return Track.COLUMNS * Tile.WIDTH / 2, -self.row * Tile.LENGTH, ground

    # Showing

    def show(self) -> None:
        """Show the editor and let the mouse paint."""
        if not self._mounted:
            self._mount()
        if not self._active:
            self._active = True
            self._container.hidden = False
            self.refresh()

    def hide(self) -> None:
        """Hide the editor and stop painting."""
        self._active = False
        self._container.hidden = True
        self.cursor.visible = self.guide.visible = False
        self._dragging = self._anchor = None

    def update(self, dt: float) -> None:
        """Ease the camera along the track and keep the cursor under the mouse, once a frame."""
        self.row += (self._target_row - self.row) * (1 - math.exp(-self.SCROLL_RATE * dt))
        if self._pointer is not None:
            self.hover = self._pick(*self._pointer)
        self._place_cursor()
        self._place_guide()

    def scroll(self, rows: float) -> None:
        """Move the camera ``rows`` along the track, toward the finish when positive."""
        top = max(self.grid.row_count, self.grid.length) + self.MARGIN_ROWS
        self._target_row = min(top, max(0.0, self._target_row + rows))

    # Keys and buttons

    def handle_key(self, code: str, letter: str = "") -> None:
        """React to the key at ``code`` pressed in the editor, typing ``letter`` on the player's layout.

        Letter shortcuts follow the layout, so Z undoes on an AZERTY keyboard too; digits and arrows go by position.
        Without a ``letter``, a letter key is taken to type its QWERTY letter.
        """
        if not letter and code.startswith("Key") and len(code) == len("KeyA"):
            letter = code[3:].lower()
        digit = next((code[len(prefix) :] for prefix in self.DIGITS if code.startswith(prefix)), "")
        action = self.LETTER_ACTIONS.get(letter)
        if action in ("previous_tool", "next_tool"):
            index = self.TOOLS.index(self.tool) + (1 if action == "next_tool" else -1)
            self.act("tool", value=self.TOOLS[index % len(self.TOOLS)].name)
        elif action is not None:
            self.act(action)
        elif code in self.SCROLL_KEYS:
            self.scroll(self.SCROLL_KEYS[code])
        elif digit.isdigit() and 1 <= int(digit) <= TrackParser.MAX_LEVEL:
            self.act("height", value=digit)
        elif code == "Escape":
            self.act(self.BACK)

    def act(self, action: str, value: str = "") -> None:
        """Carry out ``action``, from a button or a key."""
        match action:
            case self.RIDE | self.BACK:
                self._actions.append(action)
                return
            case "tool":
                self.tool = next(tool for tool in self.TOOLS if tool.name == value)
            case "height":
                self.height = min(TrackParser.MAX_LEVEL, max(1, int(value)))
            case "undo":
                if self.grid.can_undo:
                    self.grid.undo()
                    self._changed()
            case "save":
                self._save()
            case "new":
                self.open(LevelSettings(), TrackGrid.starter())
            case _:
                return
        self.refresh()

    def on_click(self, event: JsObject) -> None:
        """Carry out the action of the clicked button."""
        element = event.target.closest("[data-action]")
        if element:  # a lookup that finds nothing gives jsnull, falsy but not None
            self.act(self._data(element, "action"), self._data(element, "value"))

    def on_change(self, event: JsObject) -> None:
        """Take in a changed setting."""
        target = event.target
        field = self._data(target, "field")
        if field == "name":
            self.settings = replace(self.settings, name=str(target.value).strip() or "My track")
        elif field in ("gravity", "fuel", "oxygen"):
            try:
                value = float(target.value)
            except ValueError:
                self._sync_fields()
                return
            _, _, low, high = next(setting for setting in self.SETTINGS if setting[0] == field)
            value = min(high, max(low, value))
            key = {"gravity": "gravity", "fuel": "fuel_capacity", "oxygen": "oxygen_seconds"}[field]
            self.settings = replace(self.settings, **{key: value})
        else:
            return
        self._level = None
        self._sync_fields()
        self.refresh()

    @staticmethod
    def _data(element: JsObject, name: str) -> str:
        """Return the ``data-`` attribute ``name`` of ``element``, empty when it has none."""
        value = getattr(getattr(element, "dataset", None), name, None)
        return "" if value is None else str(value)

    # The mouse

    def on_pointer_down(self, event: JsObject) -> None:
        """Start a paint stroke where the mouse presses: the left button paints, the right one erases."""
        if not self._active or event.button not in (0, 2):
            return
        self._pointer = self._ndc(event)
        cell = self._pick(*self._pointer)
        if cell is None:
            return
        self._anchor = self.hover = cell
        self._dragging = self.ERASER if event.button == 2 else self.tool
        self._surface.setPointerCapture(event.pointerId)
        self._place_cursor()

    def on_pointer_move(self, event: JsObject) -> None:
        """Follow the mouse with the cursor, stretching the stroke's rectangle while a button is down."""
        if not self._active:
            return
        self._pointer = self._ndc(event)
        self.hover = self._pick(*self._pointer)
        self._place_cursor()

    def on_pointer_up(self, event: JsObject) -> None:
        """Paint the stroke's rectangle."""
        if self._dragging is None or self._anchor is None:
            return
        self._pointer = self._ndc(event)
        end = self._pick(*self._pointer) or self.hover or self._anchor
        tool, anchor = self._dragging, self._anchor
        self._dragging = self._anchor = None
        if self.grid.paint(Rect(*anchor, *end), tool.brush, self.height):
            self._changed()
            self.refresh()
        self._place_cursor()

    def on_pointer_leave(self, _event: JsObject) -> None:
        """Hide the cursor when the mouse leaves the view."""
        if self._dragging is None:
            self._pointer = self.hover = None
            self._place_cursor()

    def on_context_menu(self, event: JsObject) -> None:
        """Keep the browser's menu from opening on a right click, which erases."""
        event.preventDefault()

    def on_wheel(self, event: JsObject) -> None:
        """Move along the track with the mouse wheel."""
        if not self._active:
            return
        event.preventDefault()
        self.scroll(-float(event.deltaY) * self.ROWS_PER_WHEEL)

    def _ndc(self, event: JsObject) -> tuple[float, float]:
        """Return where ``event`` happened on the view, from -1 to 1 across and up."""
        width = max(1.0, float(self._surface.clientWidth or 1))
        height = max(1.0, float(self._surface.clientHeight or 1))
        return float(event.offsetX) / width * 2 - 1, 1 - float(event.offsetY) / height * 2

    def _pick(self, x: float, y: float) -> tuple[int, int] | None:
        """Return the cell under the view point ``(x, y)``."""
        three, camera = self._bridge.three, self._camera
        point = three.Vector3.new(x, y, 0.5).unproject(camera)
        eye = camera.position
        origin = (float(eye.x), float(eye.y), float(eye.z))
        direction = (float(point.x) - origin[0], float(point.y) - origin[1], float(point.z) - origin[2])
        return TrackPicker.pick(self.grid, origin, direction, self.height, clamp=self._dragging is not None)

    def _make_cursor(self) -> JsObject:
        """Return the box showing the cells the brush will paint."""
        three, bridge = self._bridge.three, self._bridge
        box = three.BoxGeometry.new(1, 1, 1)
        box.translate(0.5, 0.5, -0.5)  # from the origin toward +x, +y and -z, like the track
        self._cursor_fill = three.MeshBasicMaterial.new(
            bridge.obj(color=0xFFFFFF, transparent=True, opacity=0.22, depthWrite=False)
        )
        self._cursor_edge = three.LineBasicMaterial.new(bridge.obj(color=0xFFFFFF))
        cursor = three.Group.new()
        cursor.add(three.Mesh.new(box, self._cursor_fill))
        cursor.add(three.LineSegments.new(three.EdgesGeometry.new(box), self._cursor_edge))
        cursor.visible = False
        return cursor

    @property
    def objects(self) -> tuple[JsObject, ...]:
        """The editor's own objects in the 3D scene: the brush cursor and the guide grid."""
        return self.cursor, self.guide

    def _make_guide(self) -> JsObject:
        """Return the faint grid showing where new tiles land, at the brush height, around the camera's point."""
        three, bridge = self._bridge.three, self._bridge
        length = self.GUIDE_ROWS * Tile.LENGTH
        positions: list[float] = []
        for column in range(Track.COLUMNS + 1):
            x = column * Tile.WIDTH
            positions += [x, 0.0, 0.0, x, 0.0, -length]
        for row in range(self.GUIDE_ROWS + 1):
            z = -row * Tile.LENGTH
            positions += [0.0, 0.0, z, Track.COLUMNS * Tile.WIDTH, 0.0, z]
        geometry = three.BufferGeometry.new()
        geometry.setAttribute("position", three.BufferAttribute.new(bridge.float32_array(positions), 3))
        material = three.LineBasicMaterial.new(
            bridge.obj(color=self.GUIDE_COLOR, transparent=True, opacity=0.18, depthWrite=False)
        )
        guide = three.LineSegments.new(geometry, material)
        guide.visible = False
        return guide

    def _place_guide(self) -> None:
        """Move the guide grid under the camera's point, at the brush height."""
        first = max(0, math.floor(self.row) - self.GUIDE_BEHIND)
        self.guide.position.set(0, self.height * Tile.HEIGHT_UNIT + self.GUIDE_LIFT, -first * Tile.LENGTH)
        self.guide.visible = self._active

    def _place_cursor(self) -> None:
        """Stretch the cursor over the cell under the mouse, or over the stroke's rectangle."""
        cell = self.hover
        if not self._active or cell is None:
            self.cursor.visible = False
            return
        rect = Rect(*(self._anchor or cell), *cell)
        tool = self._dragging or self.tool
        levels = [int(found[1]) for column, row in rect.cells() if (found := self.grid.cell(column, row)) is not None]
        gaps = len(levels) < len(rect.columns) * len(rect.rows)
        top = max([*levels, *([self.height] if gaps else [])]) * Tile.HEIGHT_UNIT + self.CURSOR_LIFT
        columns, rows = rect.columns, rect.rows
        self.cursor.position.set(columns.start * Tile.WIDTH, 0, -rows.start * Tile.LENGTH)
        self.cursor.scale.set(len(columns) * Tile.WIDTH, top, len(rows) * Tile.LENGTH)
        self._cursor_fill.color.setHex(tool.color)
        self._cursor_edge.color.setHex(tool.color)
        self.cursor.visible = True

    # The toolbar

    def refresh(self) -> None:
        """Bring the toolbar up to date."""
        if not self._mounted:
            return
        self._set("editor-tools", self._tools_markup())
        self._set("editor-status", self._status_markup())

    def _set(self, element_id: str, markup: str) -> None:
        if self._shown.get(element_id) != markup:
            self._shown[element_id] = markup
            self._document.getElementById(element_id).innerHTML = markup

    def _mount(self) -> None:
        settings = "".join(
            f'<label>{label} <input type="number" id="editor-{field}" data-field="{field}"'
            f' min="{low}" max="{high}" step="1"></label>'
            for field, label, low, high in self.SETTINGS
        )
        actions = "".join(
            f'<button type="button" data-action="{action}">{escape(label)}</button>' for action, label in self.ACTIONS
        )
        self._container.innerHTML = (
            '<div class="editor-top">'
            '<input id="editor-name" class="editor-name" maxlength="40" data-field="name" aria-label="Track name">'
            f'<div class="editor-settings">{settings}</div>'
            '<div id="editor-status" class="editor-status"></div></div>'
            '<div class="editor-bottom"><div id="editor-tools" class="editor-tools"></div>'
            f'<div class="editor-actions">{actions}</div><p class="keys">{self.KEYS}</p></div>'
        )
        self._mounted = True
        self._shown.clear()
        self._sync_fields()

    def _sync_fields(self) -> None:
        """Show the level's name and settings in their fields."""
        if not self._mounted:
            return
        document, settings = self._document, self.settings
        document.getElementById("editor-name").value = settings.name
        document.getElementById("editor-gravity").value = f"{settings.gravity:g}"
        document.getElementById("editor-fuel").value = f"{settings.fuel_capacity:g}"
        document.getElementById("editor-oxygen").value = f"{settings.oxygen_seconds:g}"

    def _tools_markup(self) -> str:
        groups: dict[str, list[str]] = {}
        for tool in self.TOOLS:
            groups.setdefault(tool.group, []).append(
                f'<button type="button" class="tool{" selected" if tool is self.tool else ""}" data-action="tool"'
                f' data-value="{tool.name}" title="{escape(tool.label)}" style="color:{Palette.css(tool.color)}">'
                f"{tool.glyph}</button>"
            )
        tools = "".join(f'<div class="tool-group">{"".join(buttons)}</div>' for buttons in groups.values())
        heights = "".join(
            f'<button type="button" class="height{" selected" if level == self.height else ""}"'
            f' data-action="height" data-value="{level}" title="New tiles at height {level}">{level}</button>'
            for level in range(1, TrackParser.MAX_LEVEL + 1)
        )
        return (
            f"{tools}"
            f'<div class="tool-group"><span class="tool-caption">HEIGHT</span>{heights}</div>'
            f'<div class="tool-name">{escape(self.tool.label.upper())}</div>'
        )

    def _status_markup(self) -> str:
        track = self.level.track
        warnings = []
        if any(track.tile_at(column, 0) is None for column in (3, 4)):
            warnings.append("THE START NEEDS TILES UNDER THE MIDDLE COLUMNS")
        if not any(tile.tile_type is TileType.FINISH for tile in track.tiles()):
            warnings.append("NO FINISH LINE: THE LEVEL ENDS AT THE LAST ROW")
        new = " (NEW)" if self.index is None else ""
        markup = escape(f"{self.file}{new} · {self.grid.length} ROWS")
        markup += "".join(f'<span class="editor-warning">⚠ {escape(warning)}</span>' for warning in warnings)
        if self.message:
            markup += f'<span class="editor-message">{escape(self.message)}</span>'
        return markup

    # Saving

    def _changed(self) -> None:
        self._level = None

    def _save(self) -> None:
        """Post the level file to the server."""
        if self._saving is not None:
            self.message = f"Still saving {self._saving[1]}…"
            return
        index = len(self.files) if self.index is None or self.index >= len(self.files) else self.index
        name = self.file
        self._saving = (index, name, self.grid, self.level)
        self.message = f"Saving {name}…"
        bridge = self._bridge
        options = bridge.obj(
            method="POST", body=self.settings.write(self.grid), headers={"Content-Type": "application/json"}
        )
        bridge.window.fetch(f"{self.LEVELS_URL}{name}", options).then(self._saved_proxy).catch(self._failed_proxy)

    def on_save_response(self, response: JsObject) -> None:
        """Take in the server's answer to a save."""
        if self._saving is None:
            return
        if not response.ok:
            response.text().then(self._refused_proxy)
            return
        index, name, grid, level = self._saving
        self._saving = None
        if index == len(self.files):
            self.files.append(name)
        if grid is self.grid:
            self.index = index
        self.message = f"Saved {name}"
        if self._on_saved is not None:
            self._on_saved(index, level)
        self.refresh()

    def on_save_refused(self, text: str) -> None:
        """Show why the server refused a save."""
        self._saving = None
        self.message = f"Not saved: {text}".strip()
        self.refresh()

    def on_save_failed(self, error: JsObject) -> None:
        """Report a save that never reached the server."""
        self._saving = None
        self.message = f"Not saved, the server is unreachable: {error}"
        self.refresh()
