# Copyright (c) 2026 Renaud Guillon
# SPDX-License-Identifier: MIT

"""The browser entry point and composition root."""

from __future__ import annotations

from synthride.core.gameplay.game_session import GameSession
from synthride.core.world.level_catalog import LevelCatalog
from synthride.web.audio.sound_effects import SoundEffects
from synthride.web.audio.synth_music import SynthMusic
from synthride.web.audio.synth_voices import SynthVoices
from synthride.web.browser.browser_keyboard import BrowserKeyboard
from synthride.web.browser.full_screen import FullScreen
from synthride.web.browser.js_bridge import JsBridge
from synthride.web.browser.touch_controls import TouchControls
from synthride.web.game_loop import GameLoop
from synthride.web.rendering.neon_lines import NeonLines
from synthride.web.rendering.neon_sparks import NeonSparks
from synthride.web.rendering.scene_renderer import SceneRenderer
from synthride.web.rendering.ship_model import ShipModel
from synthride.web.rendering.ship_reflection import ShipReflection
from synthride.web.rendering.space_backdrop import SpaceBackdrop
from synthride.web.track_meshes.track_mesh_builder import TrackMeshBuilder
from synthride.web.ui.editor_screen import EditorScreen
from synthride.web.ui.hud import Hud
from synthride.web.ui.menu_screen import MenuScreen


class Main:
    """Composition root: wires the game together from a browser bridge."""

    MASTER_VOLUME = 0.6

    def __init__(self, bridge: JsBridge, catalog: LevelCatalog | None = None, *, dev: bool = False) -> None:
        """Build the game on ``bridge``, with the levels from ``catalog``, and the level editor when ``dev``."""
        self._bridge = bridge
        self._catalog = catalog or LevelCatalog()
        self._dev = dev

    def build(self) -> GameLoop:
        """Create the game loop and everything it drives."""
        bridge = self._bridge
        context = bridge.window.AudioContext.new()
        master = context.createGain()
        master.gain.value = self.MASTER_VOLUME
        master.connect(context.destination)
        lines = NeonLines(bridge)
        reflection = ShipReflection(bridge)
        session = GameSession(self._catalog.load_all())
        renderer = SceneRenderer(bridge, bridge.document.getElementById("stage"), lines, reflection=reflection)
        keyboard = BrowserKeyboard(bridge)
        TouchControls(bridge, keyboard, context.resume)  # kept alive by its listeners
        FullScreen(bridge)  # likewise
        editor = None
        if self._dev:
            files = self._catalog.file_names()
            editor = EditorScreen(bridge, renderer.renderer.domElement, renderer.camera, files, session.put_level)
        return GameLoop(
            bridge,
            session=session,
            keyboard=keyboard,
            renderer=renderer,
            track_builder=TrackMeshBuilder(bridge, lines, reflection=reflection),
            ship_model=ShipModel(bridge, lines),
            sparks=NeonSparks(bridge),
            backdrop=SpaceBackdrop(bridge),
            hud=Hud(bridge),
            menu=MenuScreen(bridge),
            music=SynthMusic(SynthVoices(bridge, context, master)),
            sound_effects=SoundEffects(SynthVoices(bridge, context, master)),
            editor=editor,
        )


def main(*, dev: bool = False) -> GameLoop:
    """Browser entry point, called by the page once Pyodide has unpacked the bundle; ``dev`` turns the editor on."""
    import js  # noqa: PLC0415  # ty: ignore[unresolved-import]  (these modules only exist inside Pyodide)
    from pyodide.ffi import create_proxy, to_js  # noqa: PLC0415  # ty: ignore[unresolved-import]

    loop = Main(JsBridge(js.window, js.THREE, create_proxy, to_js), dev=dev).build()
    loop.start()
    return loop
